﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscapeFromTheWoods.Database
{
    public class MongoDBMonkeysRepository
    {
        private IMongoClient _client;
        private IMongoDatabase _database;
        private string connectionString;

        public MongoDBMonkeysRepository(string connectionString)
        {
            this.connectionString = connectionString;
            _client = new MongoClient(connectionString);
            _database = _client.GetDatabase("Monkeys");
        }

        public void WriteWoodRecords(List<DBWoodRecord> data)
        {
            var woodRecordsCollection = _database.GetCollection<DBWoodRecord>("WoodRecords");

            foreach (var record in data)
            {
                woodRecordsCollection.InsertOne(record);
            }
        }

        public void WriteMonkeyRecords(List<DBMonkeyRecord> data)
        {
            var monkeyRecordsCollection = _database.GetCollection<DBMonkeyRecord>("MonkeyRecords");

            foreach (var record in data)
            {
                monkeyRecordsCollection.InsertOne(record);
            }
        }

        public IMongoCollection<DBWoodRecord> GetWoodCollection()
        {
            return _database.GetCollection<DBWoodRecord>("WoodRecords");
        }

        public IMongoCollection<DBMonkeyRecord> GetMonkeyCollection()
        {
            return _database.GetCollection<DBMonkeyRecord>("MonkeyRecords");
        }
    }
}
