﻿using EscapeFromTheWoods.Database;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;

namespace EscapeFromTheWoods
{
    public static class WoodBuilder
    {        
        public static Wood GetWood(int size,Map map,string path,DBwriter db)
        {
            Random r = new Random(100);
            List<Tree> trees = new List<Tree>();
            int n = 0;
            while(n<size)
            {
                Tree t = new Tree(IDgenerator.GetTreeID(),r.Next(map.xmin,map.xmax),r.Next(map.ymin,map.ymax));
                if (!trees.Contains(t)) { trees.Add(t); n++; }
            }
            Wood w = new Wood(IDgenerator.GetWoodID(),trees,map,path,db);
            return w;
        }

        public static Wood GetWoodMongo(int size, Map map, string path, MongoDBMonkeysRepository database)
        {
            Random r = new Random(100);
            List<Tree> trees = new List<Tree>();
            int n = 0;
            while (n < size)
            {
                Tree t = new Tree(IDgenerator.GetTreeID(), r.Next(map.xmin, map.xmax), r.Next(map.ymin, map.ymax));
                if (!trees.Contains(t)) { trees.Add(t); n++; }
            }

            // Use the IMongoDatabase object to interact with the MongoDB collections
            IMongoCollection<DBWoodRecord> woodCollection = database.GetWoodCollection();
            IMongoCollection<DBMonkeyRecord> monkeyCollection = database.GetMonkeyCollection();

            // Create Wood object with MongoDB collections
            Wood w = new Wood(IDgenerator.GetWoodID(), trees, map, path, woodCollection, monkeyCollection);
            return w;
        }
    }
}
