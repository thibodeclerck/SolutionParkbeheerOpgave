﻿using EscapeFromTheWoods.Database;
using System;
using System.Diagnostics;

namespace EscapeFromTheWoods
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Console.WriteLine("Hello World!");
            string connectionString = @"Data Source=PC_Thibo\SQLEXPRESS;Initial Catalog=monkeys;Integrated Security=True;TrustServerCertificate=True";
            string mongoDBString = "mongodb://localhost:27017";
            DBwriter db = new DBwriter(connectionString);
            MongoDBMonkeysRepository mongoDB = new MongoDBMonkeysRepository(mongoDBString);

            string path = @"C:\Users\thabi\OneDrive\Desktop\School\ProgSpec\EscapeFromTheWoodsToRefactor\jpegs";
            Map m1 = new Map(0, 500, 0, 500);
            Wood w1 = WoodBuilder.GetWoodMongo(500, m1, path,mongoDB);
            w1.PlaceMonkey("Alice", IDgenerator.GetMonkeyID());
            w1.PlaceMonkey("Janice", IDgenerator.GetMonkeyID());
            w1.PlaceMonkey("Toby", IDgenerator.GetMonkeyID());
            w1.PlaceMonkey("Mindy", IDgenerator.GetMonkeyID());
            w1.PlaceMonkey("Jos", IDgenerator.GetMonkeyID());
            
            Map m2 = new Map(0, 200, 0, 400);
            Wood w2 = WoodBuilder.GetWoodMongo(2500, m2, path, mongoDB);
            w2.PlaceMonkey("Tom", IDgenerator.GetMonkeyID());
            w2.PlaceMonkey("Jerry", IDgenerator.GetMonkeyID());
            w2.PlaceMonkey("Tiffany", IDgenerator.GetMonkeyID());
            w2.PlaceMonkey("Mozes", IDgenerator.GetMonkeyID());
            w2.PlaceMonkey("Jebus", IDgenerator.GetMonkeyID());

            Map m3 = new Map(0, 400, 0, 400);
            Wood w3 = WoodBuilder.GetWoodMongo(2000, m3, path, mongoDB);
            w3.PlaceMonkey("Kelly", IDgenerator.GetMonkeyID());
            w3.PlaceMonkey("Kenji", IDgenerator.GetMonkeyID());
            w3.PlaceMonkey("Kobe", IDgenerator.GetMonkeyID());
            w3.PlaceMonkey("Kendra", IDgenerator.GetMonkeyID());

            //w1.WriteWoodToDB();
            w1.WriteWoodToMongoDB();
            //w2.WriteWoodToDB();
            w2.WriteWoodToMongoDB();
            //w3.WriteWoodToDB();
            w3.WriteWoodToMongoDB();
            w1.Escape();
            w2.Escape();
            w3.Escape();
            
            stopwatch.Stop();
            // Write result.
            Console.WriteLine("Time elapsed: {0}", stopwatch.Elapsed);
            Console.WriteLine("end");
        }
    }
}
